package com.capg.paymentwallet.util;

import java.util.ArrayList;
import java.util.List;

public class Database {
	static List<String> opretions = new ArrayList<>();
	public static List<String> getOperations() {
		opretions.add( "Create account");
		opretions.add( "Show Balance");
		opretions.add( "Deposit");
		opretions.add( "Withdraw");
		opretions.add( "FundTransfer");
		opretions.add( "Print Transactions");
		opretions.add( "Exit");
		
		return opretions;
	}

}
