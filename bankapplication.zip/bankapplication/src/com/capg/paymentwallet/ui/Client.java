package com.capg.paymentwallet.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import com.capg.paymentwallet.bean.AccountBean;
import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.bean.WalletTransaction;
import com.capg.paymentwallet.exception.CustomerException;
import com.capg.paymentwallet.service.AccountServiceImpl;
import com.capg.paymentwallet.service.IAccountService;

public class Client {

	static IAccountService service = new AccountServiceImpl();
	CustomerBean customer = new CustomerBean();
	Scanner scanner = new Scanner(System.in);
	AccountBean accountBean = new AccountBean();
	static List<String> opr = service.getOperations();

	public static void main(String[] args) throws Exception {
		char ch;
		Client client = new Client();
		do {
			System.out.println("========Welcome to Payment Wallet application========");
			int i = 1;
			for (String str : opr) {

				System.out.println(i + " : " + str);
				i++;

			}

			System.out.print("Choose an option\t\t:");
			int option = client.scanner.nextInt();

			switch (option) {
			case 1:
				client.create();
				break;
			case 2:
				client.showbalance();

				break;

			case 3:
				client.deposit();

				break;

			case 4:
				client.withdraw();

				break;

			case 5:
				client.fundtransfer();

				break;

			case 6:
				client.printTransaction();

				break;
			case 7:
				System.out.print("....THANKYOU for banking....");
				System.exit(0);

				break;

			default:
				System.out
						.println("Invalid option, please choose from the above list..!");
				break;
			}

			System.out.print("Do you want to continue Y/N\t:");
			ch = client.scanner.next().charAt(0);

		} while (ch == 'y' || ch == 'Y');

	}

	AccountServiceImpl impl = new AccountServiceImpl();
	CustomerBean customerBean = new CustomerBean();

	void create() throws Exception {
		fname();
		lname();
		mail();
		phone();
		addr();
		pan();

		Random rand = new Random();
		int accId = rand.nextInt(90000000) + 1000000000;

		LocalDateTime ldt = LocalDateTime.now();
		DateTimeFormatter f = DateTimeFormatter
				.ofPattern("dd MMMM yyyy hh:mm a");
		String accDateInput = ldt.format(f);

		System.out.print("Enter balance to create account\t:");
		double balance = scanner.nextDouble();

		accountBean.setAccountId(accId);
		accountBean.setBalance(balance);
		accountBean.setInitialDeposit(balance);
		accountBean.setCustomerBean(customerBean);
		accountBean.setDateOfOpening(accDateInput);

		boolean result = service.createAccount(accountBean);
		//System.out.println(result);
		if (result) {
			System.out
					.println("\n\n\t\t\t...Congratulations!!!Your account has been created successfully...\n\n\t\t");
			System.out.print("Your Account ID is\t:");
			System.out.println(accountBean.getAccountId());
			System.out.print("\n\t\t\t....Your account has been created on " + accDateInput+"....\n");

		} else {
			System.err.println("\n\n\t\t..Enter valid details and try again..\n\n\t\t");
		}
	}

	private void pan() {
		// TODO Auto-generated method stub
		System.out.print("Enter  Customer PAN number\t:");
		String pan = scanner.next();
		if (impl.isValidPan(pan)) {
			customerBean.setPanNum(pan);
		} else {
			pan();
		}
	}

	private void phone() {
		// TODO Auto-generated method stub
		System.out.print("Enter  Customer  Phonenumber\t:");
		String phone = scanner.next();
		if (impl.isValidPhoneNum(phone)) {
			customerBean.setPhoneNo(phone);
		} else {
			phone();
		}

	}

	private void addr() {
		// TODO Auto-generated method stub
		System.out.print("Enter  Customer  address\t:");
		String address = scanner.next();
		if (impl.isValidAddr(address)) {
			customerBean.setAddress(address);
		} else {
			addr();
		}
	}

	private void mail() {
		// TODO Auto-generated method stub
		System.out.print("Enter  Customer  email id\t:");
		String email = scanner.next();
		if (impl.isValidMail(email)) {
			customerBean.setEmailId(email);
		} else {
			mail();
		}
	}

	private void lname() {
		// TODO Auto-generated method stub
		System.out.print("Enter Customer Last Name\t:");
		String lname = scanner.next();
		if (impl.isValidLName(lname)) {

			customerBean.setLastName(lname);
		} else {
			lname();
		}

	}

	private void fname() {
		System.out.print("Enter Customer First Name\t:");
		String fname = scanner.next();
		if (impl.isValidFName(fname)) {
			customerBean.setFirstName(fname);
		} else {
			fname();
		}

	}

	void showbalance() throws CustomerException, Exception {
		System.out.print("Enter Account ID\t\t:");
		int accId = scanner.nextInt();
		String accountid = Integer.toString(accId);
		AccountBean accountBean = service.findAccount(accId);

		 if(accountid.length() <10)
		{
			System.err.println("Invalid Account Number");
			System.err.println("Account number should be 10 digits and valid one.");
			showbalance();
			
		}

		double balance = accountBean.getBalance();
		System.out.println("Your balance in account with id "+accId+" is: " + balance);

	}

	void deposit() throws Exception {
		System.out.print("Enter Account ID\t\t:");
		int accId = scanner.nextInt();

		AccountBean accountBean = service.findAccount(accId);

		System.out.print("Enter amount that you want to deposit:");
		double depositAmt = scanner.nextDouble();

		WalletTransaction wt = new WalletTransaction();
		wt.setTransactionType(1);
		wt.setTransactionDate(new Date());
		wt.setTransactionAmt(depositAmt);
		//wt.setBeneficiaryAccountBean(null);

		accountBean.addTransation(wt);

		if (accountBean == null) {
			System.out.println("Account Does not exist");
			return;
		}

		boolean result = service.deposit(accountBean, depositAmt);

		if (result) {
			System.out.println("Rs."+depositAmt+" deposited into account successfully!!");
		} else {
			System.out.println("Deposite failed ");
		}

	}

	void withdraw() throws Exception {
		System.out.println("Enter Account ID");
		int accId = scanner.nextInt();

		AccountBean accountBean = service.findAccount(accId);

		System.out.println("Enter amount that you want to withdraw");
		double withdrawAmt = scanner.nextDouble();

		WalletTransaction wt = new WalletTransaction();
		wt.setTransactionType(2);
		wt.setTransactionDate(new Date());
		wt.setTransactionAmt(withdrawAmt);
		wt.setBeneficiaryAccountBean(null);

		accountBean.addTransation(wt);

		if (accountBean == null) {
			System.out.println("Account Does not exist");
			return;
		}

		boolean result = service.withdraw(accountBean, withdrawAmt);
		if (result) {
			System.out.println("Withdaw Money from Account done");
		} else {
			System.out.println("Withdaw Money from Account -Failed ");
		}

	}

	void fundtransfer() throws Exception {
		System.out.println("Enter Account ID to Transfer Money From");
		int srcAccId = scanner.nextInt();
		// IAccountService service1 =new AccountServiceImpl();
		AccountBean accountBean1 = service.findAccount(srcAccId);

		System.out.println("Current Balance is: " + accountBean.getBalance());

		System.out.println("Enter Account ID to Transfer Money to");
		int targetAccId = scanner.nextInt();

		AccountBean accountBean2 = service.findAccount(targetAccId);
		System.out.println("Name: "
				+ accountBean.getCustomerBean().getFirstName());
		System.out.println("Current Balance is: " + accountBean.getBalance());

		System.out.println("Enter amount that you want to transfer");
		double transferAmt = scanner.nextDouble();

		WalletTransaction wt = new WalletTransaction();
		wt.setTransactionType(3);
		wt.setTransactionDate(new Date());
		wt.setTransactionAmt(transferAmt);
		wt.setBeneficiaryAccountBean(accountBean2);

		accountBean1.addTransation(wt);

		WalletTransaction wt1 = new WalletTransaction();
		wt1.setTransactionType(1);
		wt1.setTransactionDate(new Date());
		wt1.setTransactionAmt(transferAmt);
		wt1.setBeneficiaryAccountBean(accountBean2);

		accountBean2.addTransation(wt1);

		boolean result = service.fundTransfer(accountBean1, accountBean2,
				transferAmt);

		if (result) {
			System.out.println("Transfering Money from Account done");
		} else {
			System.out.println("Transfering Money from Account Failed ");
		}

	}

	void printTransaction() throws Exception {
		System.out
				.println("Enter Account ID (for printing Transaction Details");
		int accId = scanner.nextInt();

		AccountBean accountBean = service.findAccount(accId);

		List<WalletTransaction> transactions = accountBean.getAllTransactions();

		/*
		 * System.out.println(accountBean);
		 * System.out.println(accountBean.getCustomerBean());
		 */

		System.out.println("Name: "
				+ accountBean.getCustomerBean().getFirstName() + " "
				+ accountBean.getCustomerBean().getLastName());
		System.out.println("Phone Number : "
				+ accountBean.getCustomerBean().getPhoneNo());
		System.out.println("Initial Deposit : "
				+ accountBean.getInitialDeposit());

		System.out
				.println("------------------------------------------------------------------");

		for (WalletTransaction wt : transactions) {

			String str = "";
			if (wt.getTransactionType() == 1) {
				str = str + "DEPOSIT";
			}
			if (wt.getTransactionType() == 2) {
				str = str + "WITHDRAW";
			}
			if (wt.getTransactionType() == 3) {
				str = str + "FUND TRANSFER";
			}

			str = str + "\t\t" + wt.getTransactionDate();

			str = str + "\t\t" + wt.getTransactionAmt();
			System.out.println(str);
		}

		System.out
				.println("------------------------------------------------------------------");

	}

}