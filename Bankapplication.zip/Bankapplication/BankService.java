package com.capg.bankapp.service;

import java.util.Scanner;

import com.capg.bankapp.bean.Bank;
import com.capg.bankapp.dao.BankDao;
import com.capg.bankapp.ui.Main;

public class BankService implements IBankService {

	BankDao dao = new BankDao();
	Main m = new Main();
	static Scanner scanner = new Scanner(System.in);
	@Override
	public boolean createAccount(Bank bank) {
		return dao.createAccount(bank);
	}

	@Override
	public Bank showBalance(long accountNumber) {
				return dao.showBalance(accountNumber);
	}

	@Override
	public double deposit(double rupees) {
		return dao.deposit(rupees);
	}

	@Override
	public double withdraw(double rupees) {
		return dao.withdraw(rupees);
	}

	@Override
	public Bank fundTransfer(long accountNumber) {
		return dao.fundTransfer(accountNumber);
	}

	

	public static boolean validateData(Bank bank) {

		boolean isValid = false;
		if (bank.getName().trim().length() > 4 && bank.getPin() > 999) {
			isValid = true;
		}
		
		return isValid;
	}
	public static boolean validateAccountNum(Bank bank)
	{
		System.out.println("Enter account number..");
		long accountNumber1 = scanner.nextLong();
		boolean isValid = false;
		if(Main.accountNumber==accountNumber1)
		{
			isValid = true;
		}
		return isValid;
		
	

}
}
